﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using CodingChallenge.DataAccess.Interfaces;
using CodingChallenge.DataAccess.Models;
using CodingChallenge.Utilities;

namespace CodingChallenge.DataAccess
{
    public class LibraryService : ILibraryService
    {
        public LibraryService() { }

        private IEnumerable<Movie> GetMovies()
        {
            return _movies ?? (_movies = ConfigurationManager.AppSettings["LibraryPath"].FromFileInExecutingDirectory().DeserializeFromXml<Library>().Movies);
        }
        private IEnumerable<Movie> _movies { get; set; }

        public int SearchMoviesCount(string title)
        {
            return SearchMovies(title).Count();
        }

        public IEnumerable<Movie> SearchMovies(string title, int? skip = null, int? take = null, string sortColumn = null, SortDirection sortDirection = SortDirection.Ascending)
        {
            HashSet<Movie> distinctMovies = new HashSet<Movie>();

            var movies = GetMovies().Where(s => s.Title.Contains(title));
            if (skip.HasValue && take.HasValue)
            {
                movies = movies.Skip(skip.Value).Take(take.Value);
            }
            if (sortColumn != null)
                switch (sortColumn.ToUpper())
                {
                    case "TITLE":
                        movies = sortDirection == SortDirection.Ascending ? movies.OrderBy(o => RemoveFirstWord(o.Title)) : movies.OrderByDescending(o => RemoveFirstWord(o.Title));
                        break;
                    case "YEAR":
                        movies = sortDirection == SortDirection.Ascending ? movies.OrderBy(o => o.Year) : movies.OrderByDescending(o => o.Year);
                        break;
                    case "RATING":
                        movies = sortDirection == SortDirection.Ascending ? movies.OrderBy(o => o.Rating) : movies.OrderByDescending(o => o.Rating);
                        break;
                    case "ID":
                        movies = sortDirection == SortDirection.Ascending ? movies.OrderBy(o => o.ID) : movies.OrderByDescending(o => o.ID);
                        break;
                    case "Franchise":
                        movies = sortDirection == SortDirection.Ascending ? movies.OrderBy(o => o.Franchise) : movies.OrderByDescending(o => o.Franchise);
                        break;
                    default:
                        break;
                }
            movies = movies.DistinctBy(s => s.Title);
            return movies;
        }



        private string RemoveFirstWord(string title)
        {
            var titles = title.Split(' ');
            var excludeList = new List<string>() { "A", "AN", "THE" };
            if (titles.Length > 1 && title.Length > 0)
            {
                int i = title.IndexOf(" ") + 1;
                var subStringTitle = title.Substring(0, i-1);
                if (excludeList.Contains(subStringTitle.ToUpper()))
                {
                    string trimTitle = title.Substring(i);
                    return trimTitle;
                }
                return title;

            }
            return title;
        }


    }
}
