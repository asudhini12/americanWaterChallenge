﻿namespace CodingChallenge.DataAccess
{
    public enum SortDirection
    {
        Ascending,
        Descending
    }
}
